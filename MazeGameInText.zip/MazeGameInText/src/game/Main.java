package game;

public class Main {
    public static void main(String[] args) {
        MazeGame game = new MazeGame();
        game.start();
    }
}
