package game;

import items.Food;
import items.PreciousStone;

public class Player {
    private int health;
    private int score;
    private boolean escaped;

    public Player() {
        health = 100;
        score = 0;
        escaped = false;
    }

    public void eat(Food food) {
        health += food.getHealthPoints();
    }

    public void collect(PreciousStone stone) {
        score += stone.getPoints();
    }

    public void move() {
        health -= 5; // Moving consumes some health
    }

    public boolean hasEscaped() {
        return escaped;
    }

    public void escape() {
        escaped = true;
    }

    public boolean isAlive() {
        return health > 0;
    }

    public int getScore() {
        return score;
    }
}
