package game;

import rooms.Room;
import rooms.RoomFactory;

import java.util.Scanner;

public class MazeGame {
    private Room currentRoom;
    private Player player;
    private Scanner scanner;

    public MazeGame() {
        currentRoom = RoomFactory.createMaze(); // Create the maze
        player = new Player();
        scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("Welcome to the Maze Escape Game!");
        System.out.println("Your goal is to escape from the maze.");

        while (!player.hasEscaped() && player.isAlive()) {
            System.out.println("\nYou are in " + currentRoom.getDescription());
            System.out.println(currentRoom.getExitsDescription());

            System.out.print("Enter your move (north/south/east/west): ");
            String direction = scanner.nextLine().toLowerCase();

            if (currentRoom.isValidExit(direction)) {
                currentRoom = currentRoom.getExit(direction);
                player.move();
                currentRoom.enter(player);
            } else {
                System.out.println("Invalid move! Try again.");
            }
        }

        if (player.hasEscaped()) {
            System.out.println("Congratulations! You've escaped from the maze!");
            System.out.println("Your final score: " + player.getScore());
        } else {
            System.out.println("Game over! You are trapped in the maze.");
        }

        scanner.close();
    }
}
