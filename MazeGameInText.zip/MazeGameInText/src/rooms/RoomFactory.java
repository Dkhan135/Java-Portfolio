package rooms;

import items.Food;
import items.Item;
import items.PreciousStone;
import java.util.Random;

public class RoomFactory {
    private static final String[] ROOM_DESCRIPTIONS = {
            "a dimly lit hallway",
            "a dusty library",
            "a spooky dungeon",
            "an abandoned laboratory",
            "a mysterious chamber",
            "a hidden treasure room",
            "a secret passage"
    };

    public static Room createMaze() {
        Room[] rooms = new Room[ROOM_DESCRIPTIONS.length];
        for (int i = 0; i < ROOM_DESCRIPTIONS.length; i++) {
            rooms[i] = new Room(ROOM_DESCRIPTIONS[i]);
        }

        Random random = new Random();
        for (int i = 0; i < rooms.length; i++) {
            for (int j = 0; j < 4; j++) {
                int randomRoomIndex = random.nextInt(ROOM_DESCRIPTIONS.length);
                rooms[i].setExit(getDirection(j), rooms[randomRoomIndex]);
            }
            rooms[i].setItem(generateRandomItem());
        }

        return rooms[0]; // Starting room
    }

    private static String getDirection(int index) {
        switch (index) {
            case 0: return "north";
            case 1: return "south";
            case 2: return "east";
            case 3: return "west";
            default: return "";
        }
    }

    private static Item generateRandomItem() {
        Random random = new Random();
        int itemType = random.nextInt(3);
        switch (itemType) {
            case 0: return new Food("Apple", 10);
            case 1: return new PreciousStone("Diamond", 50);
            case 2: return new PreciousStone("Ruby", 30);
            default: return null;
        }
    }
}
