package rooms;

import items.Food;
import items.Item;
import items.ItemType;
import items.PreciousStone;

import java.util.HashMap;
import java.util.Map;

import game.Player;

public class Room {
    private String description;
    private Map<String, Room> exits;
    private Item item;

    public Room(String description) {
        this.description = description;
        exits = new HashMap<>();
    }

    public String getDescription() {
        return description;
    }

    public void setExit(String direction, Room room) {
        exits.put(direction.toLowerCase(), room);
    }

    public boolean isValidExit(String direction) {
        return exits.containsKey(direction.toLowerCase());
    }

    public Room getExit(String direction) {
        return exits.get(direction.toLowerCase());
    }

    public String getExitsDescription() {
        StringBuilder exitsDescription = new StringBuilder("Exits: ");
        for (String direction : exits.keySet()) {
            exitsDescription.append(direction).append(", ");
        }
        return exitsDescription.toString();
    }

    public void setItem(Item item) {
        this.item = item;
    }

    public void enter(Player player) {
        if (item != null) {
            ItemType type = item.getType();
            if (type == ItemType.FOOD) {
                player.eat((Food)item);
            } else if (type == ItemType.PRECIOUS_STONE) {
                player.collect((PreciousStone)item);
            }
            System.out.println("You found " + item.getDescription());
            item = null;
        }
    }
}
