module MazeGameInText {
}