package items;

public class PreciousStone extends Item {
    private int points;

    public PreciousStone(String description, int points) {
        super(description);
        this.points = points;
    }

    public int getPoints() {
        return points;
    }

    @Override
    public ItemType getType() {
        return ItemType.PRECIOUS_STONE;
    }
}