package items;

public enum ItemType {
    FOOD,
    PRECIOUS_STONE
}
