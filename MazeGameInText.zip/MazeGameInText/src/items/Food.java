package items;

public class Food extends Item {
    private int healthPoints;

    public Food(String description, int healthPoints) {
        super(description);
        this.healthPoints = healthPoints;
    }

    public int getHealthPoints() {
        return healthPoints;
    }

    @Override
    public ItemType getType() {
        return ItemType.FOOD;
    }
}
