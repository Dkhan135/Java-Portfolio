package model;

public class Account {
    public Account(int i, String accountHolderName2, double d) {
		// TODO Auto-generated constructor stub
	}
	private int accountNumber;
    private double balance;
	public double getBalance() {
		// TODO Auto-generated method stub
		return balance;
	}
	public String getAccountHolderName() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public void setAccountHolderName(String accountHolderName) {
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

    // Constructor, getters, setters
}
