package ui;

import model.Account;
import service.BankService;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankService bankService = new BankService();

        System.out.println("Enter account holder name:");
        String accountHolderName = scanner.nextLine();

        Account account = new Account(12345, accountHolderName, 0.0);

        System.out.println("Welcome, " + account.getAccountHolderName());

        while (true) {
            System.out.println("1. Deposit");
            System.out.println("2. Withdraw");
            System.out.println("3. Check Balance");
            System.out.println("4. Exit");
            System.out.println("Choose option:");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter deposit amount:");
                    double depositAmount = scanner.nextDouble();
                    bankService.deposit(account, depositAmount);
                    break;
                case 2:
                    System.out.println("Enter withdrawal amount:");
                    double withdrawalAmount = scanner.nextDouble();
                    bankService.withdraw(account, withdrawalAmount);
                    break;
                case 3:
                    System.out.println("Current balance: " + bankService.checkBalance(account));
                    break;
                case 4:
                    System.out.println("Thank you for using our services!");
                    return;
                default:
                    System.out.println("Invalid option. Please choose again.");
            }
        }
    }
}
