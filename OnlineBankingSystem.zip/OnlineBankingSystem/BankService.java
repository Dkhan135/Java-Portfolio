package service;

import model.Account;

public class BankService {
    public void deposit(Account account, double amount) {
        double currentBalance = account.getBalance();
        double newBalance = currentBalance + amount;
        account.setBalance(newBalance);
        System.out.println("Deposited $" + amount + ". New balance: $" + newBalance);
    }

    public void withdraw(Account account, double amount) {
        double currentBalance = account.getBalance();
        if (currentBalance >= amount) {
            double newBalance = currentBalance - amount;
            account.setBalance(newBalance);
            System.out.println("Withdrawn $" + amount + ". New balance: $" + newBalance);
        } else {
            System.out.println("Insufficient funds.");
        }
    }

    public double checkBalance(Account account) {
        return account.getBalance();
    }
}