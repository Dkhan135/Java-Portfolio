module hangmanGame {
}