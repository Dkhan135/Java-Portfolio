package hangman;

import java.util.Random;
import java.util.Scanner;

public class HangmanGame {
    private static final String[] WORDS = {"hire me", "hangman", "programming", "java", "computer", "keyboard", "algorithm"};
    private Word word;
    private Player player;

    public HangmanGame(int lives) {
        Random random = new Random();
        String secretWord = WORDS[random.nextInt(WORDS.length)];
        word = new Word(secretWord);
        player = new Player(lives);
    }

    public void play() {
        Scanner scanner = new Scanner(System.in);

        while (player.isAlive() && !word.isComplete()) {
            System.out.println("Current word: " + word);
            System.out.println("Lives left: " + player.getLives());
            System.out.print("Guess a letter: ");
            char guess = scanner.next().charAt(0);

            if (!word.guessLetter(guess)) {
                player.loseLife();
                System.out.println("Incorrect guess! You lose a life.");
            }
        }

        if (word.isComplete()) {
            System.out.println("Congratulations! You guessed the word: " + word);
        } else {
            System.out.println("Game over! The word was: " + word.getSecretWord());
        }
    }

    public static void main(String[] args) {
        HangmanGame hangmanGame = new HangmanGame(5);
        hangmanGame.play();
    }
}
