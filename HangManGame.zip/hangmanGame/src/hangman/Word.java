package hangman;

public class Word {
    private String secretWord;
    private StringBuilder guessedWord;

    public Word(String secretWord) {
        this.setSecretWord(secretWord);
        guessedWord = new StringBuilder("_".repeat(secretWord.length()));
    }

    public boolean guessLetter(char letter) {
        boolean found = false;
        for (int i = 0; i < getSecretWord().length(); i++) {
            if (getSecretWord().charAt(i) == letter) {
                guessedWord.setCharAt(i, letter);
                found = true;
            }
        }
        return found;
    }

    public boolean isComplete() {
        return !guessedWord.toString().contains("_");
    }

    @Override
    public String toString() {
        return guessedWord.toString();
    }

	public String getSecretWord() {
		return secretWord;
	}

	public void setSecretWord(String secretWord) {
		this.secretWord = secretWord;
	}
}
